﻿using UnityEngine;
using System.Collections;

public class goal : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void fin ()
    {
        Debug.Log("goooooooooooooooooool!!!");
    }
}
