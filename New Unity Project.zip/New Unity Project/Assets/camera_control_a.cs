﻿using UnityEngine;
using System.Collections;

public class camera_control_a : MonoBehaviour
{

    Transform a_player;
    Transform a_transform;
    TextMesh a_ward;
    float a_squareFarRange = 1.125f;
    bool a_del = false;
    // Use this for initialization
    void Start()
    {
        a_transform = transform.FindChild("switch_ward_a").GetComponent<Transform>();
        a_player = GameObject.Find("Misaki_sum_humanoid").GetComponent<Transform>();
        a_ward = transform.FindChild("switch_ward_a").GetComponent<TextMesh>();
        a_ward.text = "a";
    }

    // Update is called once per frame
    void Update()
    {
        /*
               if(transform.FindChild("switch_ward_a").gameObject.activeSelf == true)
               {
                   transform.FindChild("switch_ward_a").gameObject.SetActive(false);
               }
         */
        //Debug.Log("a_AIFunction");

        a_AIFunction();
        if (a_del)
        {
            if (Input.GetKey("a"))
            {
                transform.FindChild("Cube_Camera").gameObject.SetActive(true);
                a_player.gameObject.SetActive(false);
            }
            else
            {
                transform.FindChild("Cube_Camera").gameObject.SetActive(false);
                a_player.gameObject.SetActive(true);
            }
        }

    }

    void a_AIFunction()
    {
        if ((a_transform.position - a_player.position).sqrMagnitude < a_squareFarRange)
        {
            transform.FindChild("switch_ward_a").gameObject.SetActive(true);
            a_del = true;
        }
        else
        {
            transform.FindChild("switch_ward_a").gameObject.SetActive(false);
            a_del = false;
        }
    }
    public void camera_move()
    {
        Debug.Log("範囲内");
    }

}
