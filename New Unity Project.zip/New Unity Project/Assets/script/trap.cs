﻿using UnityEngine;
using System.Collections;

public class trap : MonoBehaviour {

    private GameObject unit;
    private bool enable = true;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnTriggerEnter(Collider other)
    {
        unit = other.gameObject;
        Debug.Log("other.gameObject.tag :" + other.gameObject.tag);
        if (other.gameObject.layer == LayerMask.NameToLayer("Hunter") && enable)
        {
            Bind();
            Invoke("Release", 3.0f);
        }
    }

    public void Bind()
    {
        unit.GetComponent<BehaviourScript>().move = false;
        unit.transform.FindChild("switch_ward_Bind").gameObject.SetActive(true);
        this.transform.FindChild("Directional light").gameObject.SetActive(true);
       
    }

    public void Release()
    {
        unit.GetComponent<BehaviourScript>().move = true;
        unit.transform.FindChild("switch_ward_Bind").gameObject.SetActive(false);
        this.transform.FindChild("Directional light").gameObject.SetActive(false);
    }

}
