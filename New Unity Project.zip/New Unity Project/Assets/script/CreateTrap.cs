﻿using UnityEngine;
using System.Collections;

public class CreateTrap : MonoBehaviour {

    private Vector3 first_posi;
    public Transform trap;
    // Use this for initialization
	void Start () {
    }
	
	// Update is called once per frame
	void Update () {
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Floor"))
        {
            Debug.Log(this.gameObject.name);
            Transform new_trap = (Transform)Instantiate(trap);
            new_trap.transform.position = new Vector3(this.transform.position.x, 0f, this.transform.position.z);
            new_trap.gameObject.SetActive(true);
            Destroy(this.gameObject);
        }
    }
}
