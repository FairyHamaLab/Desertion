﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class BehaviourScript : MonoBehaviour {

    private Animator animator;//アニメータ
    private float Limit_time = 550;//秒
    private float timer = 0;//タイマー
    private Vector3 v = new Vector3(0, 0, 0);
    public float x, y;
    public bool move = true;//動作可能判定
    public int trap_number = 1;//保有アイテム数
    public bool trap_key = true;//トラップ配置動作制御
    public Transform Trap;
    public Transform ItemName;
	// Use this for initialization
	void Start ()
    {
        animator = GetComponent<Animator>();
    }
	
	// Update is called once per frame
	void Update () {

        v = this.transform.FindChild("PlayerCamera").transform.forward * 50;
        v += new Vector3(0f, 100f, 0f);

        if (Input.GetKey("up") && move)
        {
           animator.SetBool("running", true);
        }

        else if (Input.GetKey("down") && move)
        {
            animator.SetBool("Back", true);
        }
        else
        {
            animator.SetBool("running", false);
            animator.SetBool("Back", false);
        }  

        if (animator.GetBool("running"))
        {
            transform.position += transform.forward * 0.05f;
        }
        if (animator.GetBool("Back"))
        {
            transform.position -= transform.forward * 0.025f;
        }

        if (Input.GetKey("right") && move)
        {
            transform.Rotate(0, 5, 0);
        }
        if (Input.GetKey("left") && move)
        {
            transform.Rotate(0, -5, 0);
        }
        else
        {
            animator.SetBool("Jump", false);
            animator.SetBool("running&jump", false);
            y = 5 / 10;
        }

        if (Input.GetKeyDown("z") && move && trap_number != 0)
        {
            Transform new_trap = (Transform)Instantiate(Trap);
            new_trap.transform.position = this.transform.position;
            new_trap.transform.position += this.transform.FindChild("PlayerCamera").transform.forward + new Vector3(0f, 0.75f, 0f);
            new_trap.gameObject.GetComponent<Rigidbody>().useGravity = true;
            new_trap.gameObject.SetActive(true);
            new_trap.gameObject.GetComponent<Rigidbody>().AddForce(v);
            trap_number--;
        }

        timer += Time.deltaTime;
        Limit_time -= Time.deltaTime;
        int minutes = (int)Limit_time / 60;
        int seconds = (int)(Limit_time % 60);
        int prize = (int)timer * 200;
        this.transform.FindChild("Time").transform.FindChild("Text").GetComponent<Text>().text = "残り時間 : " + minutes.ToString().PadLeft(2, '0') + ":" + seconds.ToString().PadLeft(2, '0');
        this.transform.FindChild("Prize").transform.FindChild("Text").GetComponent<Text>().text = "賞金 : ￥" + string.Format("{0:#,0}", prize);

    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Camera"))
        {
            CameraSwitch cs = other.gameObject.GetComponent<CameraSwitch>();
            cs.getName(other.gameObject.name);
            this.transform.FindChild("switch_ward_a").gameObject.SetActive(cs.getEnable("left"));
            this.transform.FindChild("switch_ward_d").gameObject.SetActive(cs.getEnable("right"));
            cs.Trigger(true);
        }

        if (other.gameObject.layer == LayerMask.NameToLayer("Item"))
        {
            trap_number++;
            Transform new_itemname = (Transform)Instantiate(ItemName);
            new_itemname.transform.position = new Vector3(this.transform.position.x, 0f, this.transform.position.z);
            new_itemname.gameObject.SetActive(true);
        }
    }
 
    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Camera"))
        {
            CameraSwitch cs = other.gameObject.GetComponent<CameraSwitch>();
            this.transform.FindChild("switch_ward_a").gameObject.SetActive(false);
            this.transform.FindChild("switch_ward_d").gameObject.SetActive(false);
            cs.Trigger(false);
        }
    }
}
