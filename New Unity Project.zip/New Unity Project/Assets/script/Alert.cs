﻿using UnityEngine;
using System.Collections;

public class Alert : MonoBehaviour {

    //hunterが範囲内に入ったとき用のcolと、警報器を起動するために押すキーの表示のためにcolの2つを用意
    //
    private bool enable;//稼働
    private int count;
	// Use this for initialization
	void Start () {
        enable = false;
        count = 0;
        Debug.Log("alert init");
	}
	
	// Update is called once per frame
	void Update () {
        if (count == 2)
        {
            this.transform.FindChild("S").gameObject.SetActive(true);

            if (Input.GetKeyDown("s"))
            {
                enable = true;
                Debug.Log("警報器セット完了");
            }
        }
	}

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            count++;
        }

        if (other.gameObject.layer == LayerMask.NameToLayer("Hunter"))
        {
            if (enable)
            {
                Debug.Log("Alert");
                enable = false;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            count--;
            this.transform.FindChild("S").gameObject.SetActive(false);
        }
    }


}
