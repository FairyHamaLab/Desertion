﻿using UnityEngine;
using System.Collections;

public class EdgeMgr : MonoBehaviour {

    public Cell[] cells = new Cell[4];
    public Camera camera;
    public BehaviourScript player;

    /*colの番号*/
    private int trigger_number;

    /*入ったcolに対応する左右のcolの番号*/
    private static int[] set_camera_numbers_left = new int[] { 2, 3, 1, 0, };
    private static int[] set_camera_numbers_right = new int[] { 3, 2, 0, 1, };

    /*覗いてる風にするためのずらす値*/
    private static Vector3 view_slide_x = new Vector3(0.4f, 0, 0);
    private static Vector3 view_slide_z = new Vector3(0, 0, 0.4f);

    /*col内に居るかの判定*/
    private bool enable = false;

    // Use this for initialization
    void Awake()
    {
        foreach(Cell value in cells)
        {
            value.my_mgr = this;
        }

        camera.transform.localPosition = new Vector3(0, 0, 0);
    }
	void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {
        if (enable)
        {

            /*左右のcolが稼働しているなら文字を表示*/
            if (cells[set_camera_numbers_left[trigger_number]].isActiveAndEnabled)
            {
                CanvasMgr.instance.DirectionWord_display("left");
            }
            if (cells[set_camera_numbers_right[trigger_number]].isActiveAndEnabled)
            {
                CanvasMgr.instance.DirectionWord_display("right");
            }

            /*左にのぞきみ*/
            if (Input.GetKey("a") && cells[set_camera_numbers_left[trigger_number]].isActiveAndEnabled)
            {

                camera.gameObject.SetActive(true);
                player.can_move = false;

                Vector3 view_point = cells[set_camera_numbers_left[trigger_number]].transform.position;
                view_point.y = 0.5F;

                //入ったcolによって処理
                if (trigger_number == 0)
                {
                    camera.transform.localPosition = view_slide_z;
                    view_point = view_point + view_slide_z;
                }
                else if (trigger_number == 1)
                {
                    camera.transform.localPosition = -view_slide_z;
                    view_point = view_point - view_slide_z;
                }
                else if (trigger_number == 2)
                {
                    camera.transform.localPosition = view_slide_x;
                    view_point = view_point + view_slide_x;
                }
                else
                {
                    camera.transform.localPosition = -view_slide_x;
                    view_point = view_point - view_slide_x;
                }

                camera.transform.LookAt(view_point);
                camera.rect = new Rect(0.15f, 0.23f, 0.3f, 0.5f);
            }

            else if (Input.GetKey("d") && cells[set_camera_numbers_right[trigger_number]].isActiveAndEnabled)
            {

                camera.gameObject.SetActive(true);
                player.can_move = false;

                Vector3 view_point = cells[set_camera_numbers_right[trigger_number]].transform.position;
                view_point.y = 0.5F;

                /*入ったcolによって処理*/
                if (trigger_number == 0)
                {
                    camera.transform.localPosition = view_slide_z;
                    view_point += view_point + view_slide_z;
                }
                else if (trigger_number == 1)
                {
                    camera.transform.localPosition = -view_slide_z;
                    view_point = view_point - view_slide_z;
                }
                else if (trigger_number == 2)
                {
                    camera.transform.localPosition = view_slide_x;
                    view_point = view_point + view_slide_x;
                }
                else
                {
                    camera.transform.localPosition = -view_slide_x;
                    view_point = view_point - view_slide_x;
                }

                camera.transform.LookAt(view_point);
                camera.rect = new Rect(0.55f, 0.23f, 0.3f, 0.5f);
            }

            /*キーを押していないとき*/
            else
            {
                camera.gameObject.SetActive(false);
                player.can_move = true;
            }
        }
	}

    public void Trigger(int number)
    {
        trigger_number = number;
        enable = true;
    }

    /*
     * CellのOntriggerExitで呼び出し
     */
    public void disTrigger()
    {
        CanvasMgr.instance.DirectionWord_hidden();
        enable = false;
    }
}
