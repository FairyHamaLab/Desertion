﻿using UnityEngine;
using System.Collections;

public class EdgeMgr : MonoBehaviour {

    public Cell[] cells = new Cell[4];
    public Camera camera;
    // Use this for initialization
    void Awake()
    {
        foreach(Cell value in cells)
        {
            value.my_mgr = this;
        }
        camera.transform.position = new Vector3(0, 1.2F, 0);
    }
	void Start () {
	    
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void Triger(int number)
    {
        Vector3 view_point = cells[number].transform.position;
        view_point.y = 1.2F;
        camera.transform.LookAt(view_point);
    }
}
