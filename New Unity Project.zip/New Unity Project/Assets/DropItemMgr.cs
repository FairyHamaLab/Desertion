﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class DropItemMgr : MonoBehaviour {

    public static DropItemMgr instance = null;
    public GameObject bind_prefab;
    //public GameObject alert_prefab;

    void Awake()
    {
        if(instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this);
        }
    }
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
   
}
