﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour {

    public int i = 1;
   // private int x = 0;
	// Use this for initialization
	void Start () {
        Debug.Log( this.GetComponent<Transform>().position.x); 
	}
	
	// Update is called once per frame
	void Update () {
 //       this.GetComponent<Transform>().position = new Vector3( x, 0 ,0 );
 //       x++;
    }

    void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.gameObject.GetComponent<Hage>().i);
        Hage haaagee = other.gameObject.GetComponent<Hage>();
        haaagee.aaaa();

    }
}
