﻿using UnityEngine;
using System.Collections;

public class Hage : MonoBehaviour {

    public int i = 19;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        Debug.Log("GetComponentInChildren<Transform>().position.y : " + transform.FindChild("Cube").position.y);
    }

    public void aaaa()
    {
        Debug.Log("関数aaa呼び出し");
    }

}
