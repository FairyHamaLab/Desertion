﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class DeviceMgr : MonoBehaviour {

    public DeviceMgr instance;
    public Text administrator,signer;
    public GameObject door;
    public bool open;
    private int my_number;
	// Use this for initialization

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(this);
        }
    }
	void Start () {
        my_number = 0;
    }
	
	// Update is called once per frame
	void Update () {

        if (open && my_number > -90)
        {
            door.transform.Rotate(new Vector3(0, -10f, 0));
            my_number -= 10;
        }
        else if (open)
        {

        }
        else if (my_number < 0)
        {
            door.transform.Rotate(new Vector3(0, 10f, 0));
            my_number += 10;
        }
        else
        {

        }
	
	}

    void OnTriggerEnter()
    {
        CanvasMgr.instance.contract.SetActive(true);
        open = true;
    }

    void OnTriggerExit()
    {
        CanvasMgr.instance.contract.SetActive(false);
        open = false;
    }
}
