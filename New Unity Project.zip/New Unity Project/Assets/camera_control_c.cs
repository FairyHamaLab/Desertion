﻿using UnityEngine;
using System.Collections;

public class camera_control_c : MonoBehaviour
{

    Transform c_player;
    Transform c_transform;
    TextMesh c_ward;
    float c_squareFarRange = 1.125f;
    bool c_del;
    // Use this for initialization
    void Start()
    {
        c_transform = transform.FindChild("switch_ward_a").GetComponent<Transform>();
        c_player = GameObject.Find("Misaki_sum_humanoid").GetComponent<Transform>();
        c_ward = transform.FindChild("switch_ward_a").GetComponent<TextMesh>();
        c_ward.text = "c";
    }

    // Update is called once per frame
    void Update()
    {
        /*
               if(transform.FindChild("switch_ward_a").gameObject.activeSelf == true)
               {
                   transform.FindChild("switch_ward_a").gameObject.SetActive(false);
               }
         */
        c_AIFunction();
        if (c_del)
        {
            if (Input.GetKey("c"))
            {
                transform.FindChild("Cube_Camera").gameObject.SetActive(true);
                c_player.gameObject.SetActive(false);
            }
            else
            {
                transform.FindChild("Cube_Camera").gameObject.SetActive(false);
                c_player.gameObject.SetActive(true);
            }
        }

    }

    void c_AIFunction()
    {
        if ((c_transform.position - c_player.position).sqrMagnitude < c_squareFarRange)
        {
            transform.FindChild("switch_ward_a").gameObject.SetActive(true);
            c_del = true;
        }
        else
        {
            transform.FindChild("switch_ward_a").gameObject.SetActive(false);
            c_del = false;
        }
    }
    public void camera_move()
    {
        Debug.Log("範囲内");
    }

}
