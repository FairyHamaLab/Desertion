﻿using UnityEngine;
using System.Collections;

public class camera_control_b : MonoBehaviour
{

    Transform b_player;
    Transform b_transform;
    TextMesh b_ward;
    float b_squareFarRange = 1.125f;
    bool b_del;
    // Use this for initialization
    void Start()
    {
        b_transform = transform.FindChild("switch_ward_b").GetComponent<Transform>();
        b_player = GameObject.Find("Misaki_sum_humanoid").GetComponent<Transform>();
        b_ward = transform.FindChild("switch_ward_b").GetComponent<TextMesh>();
        b_ward.text = "b";
    }

    // Update is called once per frame
    void Update()
    {
        /*
               if(transform.FindChild("switch_ward_a").gameObject.activeSelf == true)
               {
                   transform.FindChild("switch_ward_a").gameObject.SetActive(false);
               }
         */
        b_AIFunction();
        if (b_del)
        {
            if (Input.GetKey("b"))
            {
                transform.FindChild("Cube_Camera").gameObject.SetActive(true);
                b_player.gameObject.SetActive(false);
            }
            else
            {
                transform.FindChild("Cube_Camera").gameObject.SetActive(false);
                b_player.gameObject.SetActive(true);
            }
        }

    }

    void b_AIFunction()
    {
        if ((b_transform.position - b_player.position).sqrMagnitude < b_squareFarRange)
        {
            transform.FindChild("switch_ward_b").gameObject.SetActive(true);
            b_del = true;
        }
        else
        {
            transform.FindChild("switch_ward_b").gameObject.SetActive(false);
            b_del = false;
        }
    }
    public void camera_move()
    {
        Debug.Log("範囲内");
    }

}
